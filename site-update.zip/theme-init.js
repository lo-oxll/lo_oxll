(function () {
  try {
    var t = localStorage.getItem('theme') || (matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light');
    document.documentElement.setAttribute('data-theme', t);
    var l = localStorage.getItem('lang');
    if (l === 'en') { document.documentElement.lang = 'en'; document.documentElement.dir = 'ltr'; }
  } catch (e) {}
})();
